create function put_event_organizer_to_participants_and_organizers() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO book_and_play.organizers (event_id, user_username)
        VALUES (NEW.id, NEW.organizer);

        INSERT INTO book_and_play.participants(event_id, user_username)
        VALUES (NEW.id, NEW.organizer);
        RETURN NEW;
    END;
$$;

alter function put_event_organizer_to_participants_and_organizers() owner to postgres;


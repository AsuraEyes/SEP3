create function update_number_of_participants() returns trigger
    language plpgsql
as
$$
DECLARE current_number_of_participants INTEGER;
        BEGIN
        SELECT COUNT(*)
            INTO current_number_of_participants
            FROM participants
            WHERE event_id = NEW.event_id;

        UPDATE book_and_play.event
            SET number_of_participants = current_number_of_participants
            WHERE id = NEW.event_id;
        RETURN NEW;
    END;
$$;

alter function update_number_of_participants() owner to postgres;

